
<?php
include "includes/db.php";

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


if (isset($_GET['uid'])) {
	
  $userid = test_input($_GET['uid']);
  $friendid = $_GET['fid'];
  


   echo json_encode(array('success' => 1, 'uid' => $userid, 'fid' => $friendid));


/*   
   global $con;
   $sql = "DELETE FROM `todo` WHERE id=".$get_id;
   if (mysqli_query($con, $sql)) {

   } else {
     echo "Error updating record: " . mysqli_error($con);
   }

mysqli_close($con);

*/

}



/*


*/



?>