
<?php
include "includes/db.php";

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


if (isset($_GET['uid']) && isset($_GET['fid']) && isset($_GET['message'])) {
	
  $userid = test_input($_GET['uid']);
  $friendid = test_input($_GET['fid']);
  $new_message = test_input($_GET['message']);

  
   // If message not empty let's add it
   if ($new_message !== "") {
   
   
   // Start Of Adding New Message
   
   /*Get Loged user name */
  $stmt = $con->prepare('SELECT * FROM users WHERE id= ?');
  $stmt->bind_param('i', $userid); 
  $stmt->execute();

  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()) {
      // Do something with $row
	  $loged_name = $row['name'];
	  $loged_image = $row['index_image'];
  }

 
    /*Get friend user name */
  $stmt = $con->prepare('SELECT * FROM users WHERE id= ?');
  $stmt->bind_param('i', $friendid); 
  $stmt->execute();

  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()) {
     // Do something with $row
	 $friend_name = $row['name'];
	 $friend_image = $row['index_image'];
  }
   
   
   
   // insert the message into the table 

   $sql = "INSERT INTO messages (body, sender_id, reciver_id) VALUES (?, ?, ?)";
           if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sii", $param_body, $param_sender, $param_reciver);
            // Set parameters
            $param_body = $new_message;
            $param_sender = $userid;
			$param_reciver = $friendid;			
		
		    // if we added the message send notification
			
			if(mysqli_stmt_execute($stmt)){
			

			
				
			echo json_encode(array('success' => 1, 'uid' => $loged_name, 'fid' => $friend_name));
			
			
			} else {

                echo mysqli_error($con) . "don't forget about notification errors";
			}			
		
		} else {
			
			 header("location: add_message.php");
		}
   
   
   
   
   
   
   
   
   
   
   
   
   
/*
            // ---------------------------------------------
			// push new notification title new_device  
			// ---------------------------------------------
			//next update give him link to that device
			
			$notifications_content = "You Sent Message To: " . $friend_name;
            $notifications_reciver_id = $userid;
			$notifications_title = "send_message";
			
            $myquery = "INSERT INTO notifications (content, reciver_id, title) VALUES('$notifications_content','$notifications_reciver_id','$notifications_title')";
            $myresult = mysqli_query($con, $myquery);

            if (!$myresult) {
			
			   // if can't add notifiction show error
               die("Could not send data " . mysqli_error($con));
            }
            else{
			  // if notification created and mysqli_stmt_execute($stmt) added device redirect to workstation page 
              //echo "submited";
			  
			  //#######################################################
			  // Sucess Part  This send the response to the client side 
			  //#######################################################
			  
              
            }

            // end push



*/   
   
   
   
   
   
   
   
   
   
   
   // End Of adding New Message   
   
   } else {
	   // if message empty return success 0 to know there is no message + to have better performance
	   // its important becuase we don't need add empty rows to database table messages
	   echo json_encode(array('success' => 0));
   }
    
   
}  
 // End Of the COde  
   
   
   
   
   
   
   
   
   
   
/*   
   global $con;
   $sql = "DELETE FROM `todo` WHERE id=".$get_id;
   if (mysqli_query($con, $sql)) {

   } else {
     echo "Error updating record: " . mysqli_error($con);
   }

mysqli_close($con);

*/





/*


*/



?>